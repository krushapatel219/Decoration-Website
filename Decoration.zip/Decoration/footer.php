<footer class="site-footer">
        <div class="footer-top">
            <div class="container footer-grid">
                <!-- Logo & Description -->
                <div class="footer-logo">
                    <img src="images/logo.png" alt="Mandap Logo" class="logo-img">
                    <p>Elevate your celebrations with Novelty Mandap Service — crafting unforgettable wedding & event
                        decor.</p>
                </div>

                <!-- Navigation -->
                <div class="footer-nav-section">
                    <h3>Navigation</h3>
                    <ul>
                        <li><a href="index.html">Home</a></li>
                        <li><a href="about.html">About</a></li>
                        <li><a href="services.html">Services</a></li>
                        <li><a href="gallery.html">Gallery</a></li>
                        <li><a href="contact.html">Contact</a></li>
                    </ul>
                </div>

                <!-- Portfolio / Services -->
                <div class="footer-portfolio">
                    <h3>Portfolio</h3>
                    <ul>
                        <li><a href="#">Mandaps</a></li>
                        <li><a href="#">Birthday Themes</a></li>
                        <li><a href="#">Corporate Events</a></li>
                        <li><a href="#">Home & Festival Décor</a></li>
                    </ul>
                </div>

                <!-- Contact -->
                <div class="footer-contact">
                    <h3>Get in Touch</h3>
                    <p>📧 <a href="mailto:info@mandapservice.com">info@mandapservice.com</a></p>
                    <p>📍 123 Celebration St, Wedding City, Country</p>
                    <div class="footer-socials">
                        <a href="#"><img src="images/facebook.svg" alt="Facebook"></a>
                        <a href="#"><img src="images/twitter.svg" alt="Twitter"></a>
                        <a href="#"><img src="images/linkedin.svg" alt="LinkedIn"></a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bottom copyright -->
        <div class="footer-bottom">
            <div class="container">
                <p>© <span id="year"></span> Novelty Mandap Service</p>
            </div>
        </div>
    </footer>