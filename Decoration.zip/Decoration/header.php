<?php include "Admin/config/db.php"; ?>
  <header class="d-flex justify-content-between align-items-center">
 <div class="logo">
    <a href="index.php">
        <img src="image/logo.jpg" alt="Mandap Decor Logo" height="60">
    </a>
</div>
    <nav>
      <ul class="menu d-flex gap-4">
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">About</a></li>

        <!-- Services Dropdown -->
        <li class="dropdown">
    <a href="#" class="dropdown-toggle" data-bs-toggle="dropdown">Services</a>

    <ul class="dropdown-menu">

        <?php
        

        $result = mysqli_query($conn, "SELECT * FROM services ORDER BY service_name ASC");

        while($row = mysqli_fetch_assoc($result)){
        ?>
            <li>
                <a class="dropdown-item"
                   href="service-details.php?id=<?php echo $row['service_id']; ?>">
                    <?php echo htmlspecialchars($row['service_name']); ?>
                </a>
            </li>
        <?php } ?>

    </ul>
</li>

        <li><a href="gallery.php">Gallery</a></li>
        <li><a href="contact.php">Contact</a></li>
      </ul>
    </nav>


  </header>
