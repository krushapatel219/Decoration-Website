<?php 
include "config/db.php"; 

$msg = "";

if(isset($_POST['register'])){

    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password']; // Simple password (not hashed)

    $stmt = $conn->prepare("INSERT INTO admins (name, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $password);

    if($stmt->execute()){
        header("Location: login.php");
        exit();
    } else {
        $msg = "Error: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Register</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    background: linear-gradient(to right, #141e30, #243b55);
}
.card {
    color: white;
    background-color: #1f2d3d;
}
.password-box {
    position: relative;
}

.password-box input {
    padding-right: 45px;
}

.toggle-password {
    position: absolute;
    right: 15px;
    top: 10px;
    cursor: pointer;
    font-size: 20px;
    color: #555;
}
</style>

</head>
<body>

<div class="container d-flex justify-content-center align-items-center vh-100">
<div class="col-md-4">

<div class="card shadow p-4">
<h3 class="text-center text-info">Admin Register</h3>

<?php if($msg): ?>
<div class="alert alert-danger"><?php echo $msg; ?></div>
<?php endif; ?>

<form method="POST">
<input type="text" name="name" class="form-control mb-3" placeholder="Name" required>
<input type="email" name="email" class="form-control mb-3" placeholder="Email" required>
<div class="password-box">
    <input type="password" name="password" id="password" class="form-control mb-3" placeholder="Password" required>

    <span class="toggle-password" onclick="showPassword()">
        👁️
    </span>
</div>

<button class="btn btn-info w-100" name="register">Register</button>

<a href="login.php" class="btn btn-outline-light w-100 mt-2">
    Back to Login
</a>
</form>

</div>

</div>
</div>
<script>
function showPassword() {
    let password = document.getElementById("password");
    let icon = document.querySelector(".toggle-password");

    if (password.type === "password") {
        password.type = "text";
        icon.innerHTML = "🙈";
    } else {
        password.type = "password";
        icon.innerHTML = "👁️";
    }
}
</script>
</body>
</html>