<?php
session_start();
if(!isset($_SESSION['admin_id'])){
    header("Location: login.php");
    exit();
}
include "config/db.php";
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - Service Table</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <!-- SIDEBAR -->
    <?php include "sidebar.php"; ?>

    <!-- MAIN WRAPPER -->
    <div class="main">

        <!-- TOPBAR -->
        <?php include "topbar.php"; ?>

        <!-- CONTENT -->
        <div class="content-area container-fluid p-4">

            <!-- PAGE HEADER -->
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h3 class="mb-0">Service Table</h3>
                <button class="btn btn-primary">
                    <a href="add_service.php" class="btn btn-primary text-light">
                        <i class="bi bi-plus-circle"></i> Add Service
                    </a>
                </button>
            </div>

            <!-- CARD -->
            <div class="card shadow-sm">
                <div class="card-body">

                    <table class="table table-hover table-bordered align-middle">
                        <thead class="table-dark">
                            <tr>
                                <th>ID</th>
                                <th>Service Name</th>
                                <th>Description</th>
                                <th>Price</th>
                                <th>Image</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                        $sql = $conn->query("SELECT * FROM services");
                        while($row = $sql->fetch_assoc()){
                        ?>
                            <tr>
                                <td><?php echo $row['service_id']; ?></td>
                                <td><?php echo $row['service_name']; ?></td>
                                <td><?php echo $row['description']; ?></td>
                                <td>$<?php echo $row['price']; ?></td>
                                <td>
                                    <img src="uploads/services/<?php echo $row['image']; ?>" width="80" height="80"
                                        style="object-fit:cover;border-radius:8px;">
                                </td>
                                <td>
                                    <a href="service_edit.php?service_id=<?php echo $row['service_id']; ?>"
                                        class="btn btn-sm btn-warning">
                                        Edit
                                    </a>
                                    <button class="btn btn-sm btn-danger">Delete</button>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>

                    </table>

                </div>
            </div>

        </div>
    </div>

</body>

</html>