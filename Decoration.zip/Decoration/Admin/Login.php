<?php 
session_start();
include "config/db.php"; 

$error = "";

if(isset($_POST['login'])){

    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM admins WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();

    $result = $stmt->get_result();

    if($result->num_rows > 0){

        $admin = $result->fetch_assoc();

        // Simple password check (without hash)
        if($password == $admin['password']){

            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_name'] = $admin['name'];

            header("Location: index.php");
            exit();

        } else {
            $error = "Wrong password!";
        }

    } else {
        $error = "Admin not found!";
    }
}
?>
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    background: linear-gradient(to right, #00c6ff, #0072ff);
}
</style>

</head>
<body>

<div class="container d-flex justify-content-center align-items-center vh-100">
<div class="col-md-4">

<div class="card shadow p-4">
<h3 class="text-center text-primary">Admin Login</h3>

<?php if($error): ?>
<div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<form method="POST">
<input type="email" name="email" class="form-control mb-3" placeholder="Email" required>
<div class="position-relative">
    <input type="password" 
           name="password" 
           id="password"
           class="form-control mb-3" 
           placeholder="Password" 
           required>

    <span onclick="togglePassword()" 
          style="
          position:absolute;
          right:15px;
          top:8px;
          cursor:pointer;
          font-size:22px;">
        👁️
    </span>
</div>

<button class="btn btn-primary w-100" name="login">Login</button>

<a href="Register.php" class="btn btn-outline-dark w-100 mt-2">
    Create Admin Account
</a>
</form>

</div>

</div>
</div>

</body>
<script>
function togglePassword(){

    let pass = document.getElementById("password");

    if(pass.type === "password"){
        pass.type = "text";
    }
    else{
        pass.type = "password";
    }

}
</script>
</html>