<?php
session_start();
if(!isset($_SESSION['admin_id'])){
    header("Location: login.php");
    exit();
}
include "config/db.php";

$msg = "";

if(isset($_POST['submit'])){

    $service_name = $_POST['service_name'];
    $desc = $_POST['description'];
    $price = $_POST['price'];

    // Image Upload
    $image_name = $_FILES['image']['name'];
    $tmp_name = $_FILES['image']['tmp_name'];

    $upload_dir = "uploads/services/";

    if(!file_exists($upload_dir)){
        mkdir($upload_dir, 0777, true);
    }

    $new_image = time() . "_" . $image_name;

    move_uploaded_file($tmp_name, $upload_dir . $new_image);

    $stmt = $conn->prepare("INSERT INTO services (service_name, description, price, image) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $service_name, $desc, $price, $new_image);

    if($stmt->execute()){
        header("Location: services.php");
        exit();
    } else {
        $msg = "Error: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - Service Table</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/style.css">
</head>

<body class="bg-light">
    <?php include "sidebar.php"; ?>

    <!-- MAIN WRAPPER -->
    <div class="main">

        <!-- TOPBAR -->
        <?php include "topbar.php"; ?>

        <div class="container mt-5">

            <div class="col-md-6 mx-auto">

                <div class="card shadow p-4">

                    <h3 class="text-center mb-3">Add Service</h3>

                    <?php if($msg): ?>
                    <div class="alert alert-danger"><?php echo $msg; ?></div>
                    <?php endif; ?>

                    <form method="POST" enctype="multipart/form-data">

                        <label>Service Name</label>
                        <input type="text" name="service_name" class="form-control mb-3" required>

                        <label>Description</label>
                        <input type="text" name="description" class="form-control mb-3" required>

                        <label>Price</label>
                        <input type="number" name="price" class="form-control mb-3" required>

                        <label>Service Image</label>
                        <input type="file" name="image" class="form-control mb-3" accept="image/*" required>

                        <button type="submit" name="submit" class="btn btn-success w-100">
                            Save Service
                        </button>

                        <a href="services.php" class="btn btn-secondary w-100 mt-2">
                            Back
                        </a>

                    </form>

                </div>

            </div>

        </div>
    </div>

</body>

</html>