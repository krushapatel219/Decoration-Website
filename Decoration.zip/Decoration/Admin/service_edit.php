<?php
session_start();

if(!isset($_SESSION['admin_id'])){
    header("Location: login.php");
    exit();
}

include "config/db.php";


if(!isset($_GET['service_id'])){
    header("Location: service.php");
    exit();
}

$id = $_GET['service_id'];


// Fetch Service Data
$stmt = $conn->prepare("SELECT * FROM services WHERE service_id=?");
$stmt->bind_param("i",$id);
$stmt->execute();

$result = $stmt->get_result();
$service = $result->fetch_assoc();



// Update Service
if(isset($_POST['update'])){

    $service_name = $_POST['service_name'];
    $description  = $_POST['description'];


    // Old Image
    $image = $service['image'];


    // Image Upload
    if(isset($_FILES['image']) && $_FILES['image']['name'] != ""){


        $img_name = $_FILES['image']['name'];
        $tmp_name = $_FILES['image']['tmp_name'];

        $new_image = time()."_".$img_name;

        $path = "uploads/services/".$new_image;


        move_uploaded_file($tmp_name,$path);


        // delete old image
        if(file_exists("uploads/services/".$image)){
            unlink("uploads/services/".$image);
        }


        $image = $new_image;

    }



    // Update only name description image
    $stmt = $conn->prepare(
        "UPDATE services 
        SET service_name=?, description=?, image=? 
        WHERE service_id=?"
    );


    $stmt->bind_param(
        "sssi",
        $service_name,
        $description,
        $image,
        $id
    );



    if($stmt->execute()){

        echo "
        <script>
        alert('Service Updated Successfully');
        window.location='services.php';
        </script>
        ";

        exit();

    }

}

?>

<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">
    <title>Edit Service</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="css/style.css">

</head>


<body class="bg-light">


    <?php include "sidebar.php"; ?>


    <div class="main">

        <?php include "topbar.php"; ?>


        <div class="container mt-5">


            <div class="card shadow">

                <div class="card-body">


                    <h3>Edit Service</h3>


                    <form method="POST" enctype="multipart/form-data">


                        <label>Service Name</label>

                        <input type="text" name="service_name" class="form-control mb-3"
                            value="<?php echo $service['service_name']; ?>" required>



                        <label>Description</label>

                        <textarea name="description"
                            class="form-control mb-3"><?php echo $service['description']; ?></textarea>



                        <label>Service Image</label>

                        <input type="file" name="image" class="form-control mb-3">



                        <?php if($service['image']!=""){ ?>

                        <img src="uploads/services/<?php echo $service['image']; ?>" width="120" class="mb-3 rounded">

                        <?php } ?>



                        <!-- Price Display Only -->

                        <!-- <label>Price</label>

                        <input type="number" class="form-control mb-3" value="<?php echo $service['price']; ?>"
                            readonly> -->



                        <button type="submit" name="update" class="btn btn-success w-100">

                            Update Service

                        </button>


                        <a href="services.php" class="btn btn-secondary w-100 mt-2">

                            Back

                        </a>


                    </form>


                </div>

            </div>


        </div>


    </div>


</body>

</html>