 <div class="topbar">
            <h4 class="mb-0">🎉 Event Management Dashboard</h4>

            <div>
                <i class="bi bi-bell me-3"></i>

                <!-- CLICKABLE ADMIN + LOGOUT -->
                <a href="logout.php" class="text-black text-decoration-none">
                    <i class="bi bi-person-circle me-1"></i>
                    <?php echo $_SESSION['admin_name']; ?>
                </a>
            </div>
        </div>