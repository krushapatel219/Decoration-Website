   <div class="sidebar">
        <h3>Event Admin</h3>
        <a href="#"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <a href="services.php"><i class="bi bi-calendar-event"></i> Service Table</a>
        <a href="#"><i class="bi bi-people"></i> User Table</a>
    </div>