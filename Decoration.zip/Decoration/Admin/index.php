<?php include "config/db.php"; ?>
<?php
session_start();

if(!isset($_SESSION['admin_id'])){
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Management Admin Panel</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="css/style.css" />
</head>

<body>

    <!-- Sidebar -->
     <?php include "sidebar.php"; ?>


    <!-- Main -->
    <div class="main">

        <!-- Topbar -->

       <?php include "topbar.php"; ?>

        <!-- Stats -->
        <div class="row mt-4 g-3">

            <div class="col-md-3">
                <div class="stat blue">
                    <h5>Total Events</h5>
                    <h2>45</h2>
                </div>
            </div>

            <div class="col-md-3">
                <div class="stat green">
                    <h5>Tickets Sold</h5>
                    <h2>1,250</h2>
                </div>
            </div>

            <div class="col-md-3">
                <div class="stat orange">
                    <h5>Active Events</h5>
                    <h2>12</h2>
                </div>
            </div>

            <div class="col-md-3">
                <div class="stat purple">
                    <h5>Revenue</h5>
                    <h2>$18,500</h2>
                </div>
            </div>

        </div>

        <!-- Chart + Actions -->
        <div class="row mt-4 g-3">

            <!-- Chart -->
            <div class="col-md-8">
                <div class="card-box">
                    <h5>📊 Event Ticket Sales</h5>
                    <canvas id="chart"></canvas>
                </div>
            </div>

            <!-- Actions -->
            <div class="col-md-4">
                <div class="card-box">
                    <h5>⚡ Quick Actions</h5>

                    <button class="action-btn btn1">Create Event</button>
                    <button class="action-btn btn2">Add Attendee</button>
                    <button class="action-btn btn3">Generate Tickets</button>
                    <button class="action-btn btn4">View Reports</button>

                </div>
            </div>

        </div>

        <!-- Tables -->
        <div class="row mt-4 g-3">

            <!-- Events -->
            <div class="col-md-6">
                <div class="card-box">
                    <h5>📅 Upcoming Events</h5>

                    <table class="table table-hover mt-3">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Event</th>
                                <th>Date</th>
                                <th>Status</th>
                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                                <td>#E01</td>
                                <td>Music Festival</td>
                                <td>10 June</td>
                                <td><span class="badge bg-success">Active</span></td>
                            </tr>

                            <tr>
                                <td>#E02</td>
                                <td>Tech Conference</td>
                                <td>18 June</td>
                                <td><span class="badge bg-warning">Upcoming</span></td>
                            </tr>

                            <tr>
                                <td>#E03</td>
                                <td>Wedding Expo</td>
                                <td>25 June</td>
                                <td><span class="badge bg-success">Active</span></td>
                            </tr>
                        </tbody>

                    </table>

                </div>
            </div>

            <!-- Notifications -->
            <div class="col-md-6">
                <div class="card-box">
                    <h5>🔔 Notifications</h5>

                    <ul class="list-group mt-3">
                        <li class="list-group-item">New event created</li>
                        <li class="list-group-item">Ticket sales increased</li>
                        <li class="list-group-item">New attendee registered</li>
                        <li class="list-group-item">Payment received</li>
                    </ul>

                </div>
            </div>

        </div>

    </div>

    <!-- Chart -->
    <script>
    new Chart(document.getElementById("chart"), {
        type: "bar",
        data: {
            labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
            datasets: [{
                label: "Tickets Sold",
                data: [200, 350, 300, 500, 450, 600],
                backgroundColor: "#3b82f6"
            }]
        }
    });
    </script>

</body>

</html>