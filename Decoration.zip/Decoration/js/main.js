<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>


let index = 0;
const slides = document.getElementsByClassName("slides");

function showSlides() {
  for (let i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  index++;
  if (index > slides.length) { index = 1; }
  slides[index-1].style.display = "block";
  setTimeout(showSlides, 4000);
}
showSlides();

function previewNow() {
  alert("Previewing your beautiful decoration setup!");
}
{/* <script>
  document.getElementById('year').textContent = new Date().getFullYear();
</script> */}
