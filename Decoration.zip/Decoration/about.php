<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>About us</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Animate.css for animations -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link rel="stylesheet" href="css/styles.css" />
</head>

<body>
    <!-- HEADER -->
    <?php
        include 'header.php';
    ?>

    <section class="py-5">
        <div class="container">
            <div class="about-banner">
            </div>

            <div class="container about-section">
                <div class="row align-items-center">

                    <div class="col-md-6 mb-4 mb-md-0">
                        <img src="image/About.jpeg" class="img-fluid rounded about-img" alt="Couple">
                    </div>

                    <div class="col-md-6">
                        <p class="lead">
                        <h1>Our Love Story</h1><br>
                        <p>
                            Two hearts, one beautiful story, and a journey written by destiny.
                            What started as a simple meeting slowly turned into laughter, friendship,
                            trust, and unconditional love.
                        </p>
                        <p>
                            Through every conversation, every memory, and every moment shared,
                            we discovered something truly special — a bond meant to last forever.
                            Today, we are not just two individuals, but one story, one promise,
                            and one forever.
                        </p>
                        </p>
                        <a href="index.php" class="btn rounded-pill px-4 mt-2 about-btn">
                            Back To Home
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <?php
      include 'footer.php';
    ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Counter Script -->
    <script>
    // Set current year
    document.getElementById('year').textContent = new Date().getFullYear();

    // Counter Animation
    const counters = document.querySelectorAll('.counter');
    counters.forEach(counter => {
        const updateCount = () => {
            const target = +counter.getAttribute('data-target');
            const count = +counter.innerText;
            const increment = target / 200;
            if (count < target) {
                counter.innerText = Math.ceil(count + increment);
                setTimeout(updateCount, 10);
            } else {
                counter.innerText = target;
            }
        };
        updateCount();
    });
    </script>
    <script src="js/main.js" defer></script>
</body>

</html>