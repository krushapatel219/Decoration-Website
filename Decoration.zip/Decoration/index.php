<?php include "Admin/config/db.php"; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Mandap Decor | Elegant Wedding Design</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Animate.css for animations -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link rel="stylesheet" href="css/styles.css" />
</head>

<body>

    <!-- HEADER -->
    <?php
        include 'header.php';
    ?>

    <!-- HERO / BANNER -->
    <section id="home" class="hero">
        <div class="hero-content">
            <h1>Celebrate Love with Elegance</h1>
            <p>Luxurious mandap decorations crafted for unforgettable moments.</p>
            <a href="#contact" class="btn">Book Your Event</a>
        </div>
    </section>

    <!-- ABOUT -->
    <section id="about" class="about py-5">
        <div class="container">
            <div class="row align-items-center">

                <!-- Image Column -->
                <div class="col-md-6 mb-4 mb-md-0 animate__animated animate__fadeInLeft">
                    <img src="image/about.jpeg" alt="Mandap About" class="img-fluid rounded shadow">
                </div>

                <!-- Text Column -->
                <div class="col-md-6 animate__animated animate__fadeInRight">
                    <h2 class="mb-3">About Us</h2>
                    <p>
                        At <strong>Novelty Mandap Service</strong>, we bring dreams to life with stunning mandap designs
                        and unforgettable event decorations. With years of experience in wedding and event décor, our
                        team
                        blends creativity, culture, and craftsmanship to make every celebration magical.
                    </p>
                    <p>
                        From traditional wedding mandaps to elegant modern setups, we offer full-service decoration
                        solutions for weddings, engagements, birthdays, and corporate events. Every detail — from
                        flowers
                        and fabrics to lighting and stage design — is handled with love and precision.
                    </p>

                    <a href="about.php" class="btn btn-primary rounded-pill px-4 mt-2">Learn More</a>
                </div>

            </div>
        </div>
    </section>


    <section class="stats">
        <div class="container">
            <div class="stat-box">
                <h3 class="counter" data-target="120">0</h3>
                <span class="plus">+</span>
                <p>Weddings Planned</p>
            </div>
            <div class="stat-box">
                <h3 class="counter" data-target="85">0</h3>
                <span class="plus">+</span>
                <p>Decor Themes</p>
            </div>
            <div class="stat-box">
                <h3 class="counter" data-target="50">0</h3>
                <span class="plus">+</span>
                <p>Happy Couples</p>
            </div>
            <div class="stat-box">
                <h3 class="counter" data-target="10">0</h3>
                <span class="plus">+</span>
                <p>Years of Experience</p>
            </div>
        </div>
    </section>

    <!-- SERVICES -->
    <?php
// include "config/db.php";

$result = mysqli_query($conn, "SELECT * FROM services ORDER BY service_id  DESC");

$services = [];
while($row = mysqli_fetch_assoc($result)){
    $services[] = $row;
}

$chunks = array_chunk($services, 3);
?>

    <section id="services" class="services py-5">
        <div class="container text-center">

            <h2 class="mb-3">Our Services</h2>
            <p class="subtitle mb-5 text-muted">
                We craft beautiful experiences for every occasion.
            </p>

            <div id="serviceSlider" class="carousel slide" data-bs-ride="carousel">

                <div class="carousel-inner">

                    <?php foreach($chunks as $index => $chunk){ ?>
                    <div class="carousel-item <?php echo ($index == 0) ? 'active' : ''; ?>">
                        <div class="row g-4">

                            <?php foreach($chunk as $service){ ?>
                            <div class="col-md-4">
                                <div class="card h-100 shadow-sm border-0">

                                    <img src="Admin/uploads/services/<?php echo $service['image']; ?>" class="card-img-top"
                                        style="height:250px; object-fit:cover;"
                                        alt="<?php echo $service['service_name']; ?>">

                                    <div class="card-body">

                                        <h5>
                                            <a href="service-details.php?service_id=<?php echo $service['service_id']; ?>"
                                                class="text-decoration-none text-dark">
                                                <?php echo $service['service_name']; ?>
                                            </a>
                                        </h5>

                                        <!-- <p class="text-muted">
                                            <?php echo substr($service['description'],0,80); ?>
                                        </p> -->

                                        <!-- <h6 class="text-primary">
                                            $<?php echo $service['price']; ?>
                                        </h6> -->

                                    </div>
                                </div>
                            </div>
                            <?php } ?>

                        </div>
                    </div>
                    <?php } ?>

                </div>

                <?php if(count($services) > 3){ ?>

                <button class="carousel-control-prev" type="button" data-bs-target="#serviceSlider"
                    data-bs-slide="prev">
                    <span class="carousel-control-prev-icon"></span>
                </button>

                <button class="carousel-control-next" type="button" data-bs-target="#serviceSlider"
                    data-bs-slide="next">
                    <span class="carousel-control-next-icon"></span>
                </button>

                <?php } ?>

            </div>

        </div>
    </section>

    <!-- GALLERY -->
    <section id="gallery" class="gallery">
        <div class="container">
            <h2>Our Gallery</h2>
            <p class="subtitle">A glimpse into our magical mandap creations</p>

            <div class="gallery-slider">
                <div class="slide-track">
                    <div class="slide">
                        <img src="https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?q=80&w=600"
                            alt="Stage Setup">
                    </div>
                    <div class="slide">
                        <img src="https://images.unsplash.com/photo-1532635241-17e820acc59f?q=80&w=600"
                            alt="Floral Design">
                    </div>
                    <div class="slide">
                        <img src="https://images.unsplash.com/photo-1528784351875-d797d86873a1?q=80&w=600"
                            alt="Lighting Decor">
                    </div>

                    <!-- Duplicate slides for seamless infinite scroll -->
                    <div class="slide">
                        <img src="https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?q=80&w=600"
                            alt="Stage Setup">
                    </div>
                    <div class="slide">
                        <img src="https://images.unsplash.com/photo-1532635241-17e820acc59f?q=80&w=600"
                            alt="Floral Design">
                    </div>
                    <div class="slide">
                        <img src="https://images.unsplash.com/photo-1528784351875-d797d86873a1?q=80&w=600"
                            alt="Lighting Decor">
                    </div>
                </div>
            </div>
            <a href="gallery.html" class="btn-view-gallery">View Gallery</a>
        </div>
    </section>

    <!-- CONTACT -->
<section id="contact" class="contact">
    <h2>Contact Us</h2>
    <p>Let’s plan your perfect celebration together.</p>

    <div class="contact-info">
        <p>Naresh Bhai :-📞 +91 98246 11324</p>
        <p>Vipul Bhai :-📞 +91 99044 56976</p>
        <p>📧 krushapatel219@gmail.com</p>
        <p>📍 Kalol, India</p>
    </div>
</section>

    <!-- FOOTER -->
    <?php
      include 'footer.php';
    ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Counter Script -->
    <script>
    // Set current year
    document.getElementById('year').textContent = new Date().getFullYear();

    // Counter Animation
    const counters = document.querySelectorAll('.counter');
    counters.forEach(counter => {
        const updateCount = () => {
            const target = +counter.getAttribute('data-target');
            const count = +counter.innerText;
            const increment = target / 200;
            if (count < target) {
                counter.innerText = Math.ceil(count + increment);
                setTimeout(updateCount, 10);
            } else {
                counter.innerText = target;
            }
        };
        updateCount();
    });
    </script>
    <script src="js/main.js" defer></script>
</body>

</html>